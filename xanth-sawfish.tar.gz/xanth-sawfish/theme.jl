;; Name    : xanth-sawfish. Based on candido theme.
;; Author  : Okeke Uchechukwu (clemencyworld@yahoo.com)
;; License : GPL-2

(let*
  (
      (itopleft (list (make-image "topleft.png")      nil nil nil))
    (itopright   (list (make-image "topright.png")        nil nil nil))
    (itopcenter-left   (list (make-image "title.png")        nil nil nil))
    (itopcenter-center   (list (make-image "center.png")        nil nil nil))
    (itopcenter-right   (list (make-image "topright-center.png")        nil nil nil))
    (ibottom (list (make-image "bottom.png")      nil nil nil))
    (ileft   (list (make-image "left.png")        nil nil nil))
    (iright  (list (make-image "right.png")       nil nil nil))
    (ibottomright     (list (make-image "bottomright.png")          nil nil nil))
    (ibottomleft     (list (make-image "bottomleft.png")          nil nil nil))
    (ititle  (list (make-image "title.png")       nil nil nil))
    (imin    (list (make-image "min.png")         nil (make-image "min_active.png")   nil))
    (imax    (list (make-image "max.png")         nil (make-image "max_active.png")   nil))
    (iclose  (list (make-image "close.png")       nil (make-image "close_active.png") nil))
    (imenu   (list (make-image "menu.png")        nil (make-image "menu_active.png")  nil))
    
    (default-frame
     `(
        ((background . ,itopright)  (right-edge . -9) (top-edge . -30) (class . title))
        ((background . ,itopcenter-right)  (right-edge . 90) (width . 80) (top-edge . -30) (class . title))
        ((background . ,itopcenter-center)  (right-edge . 0) (width . 90)(top-edge . -30) (class . title))
        ((background . ,itopcenter-left)  (left-edge . 0) (width . 50)(top-edge . -30) (class . title))
        ((background . ,itopleft) (left-edge . -6) (height . 30) (top-edge . -30) (class . title))
        ((background . ,ititle)  (right-edge . 170) (left-edge . 50) (top-edge . -30) 
         (foreground . ("red" "blue"))  (text . ,window-name) (x-justify . center) (y-justify . bottom) (class . title))
         ((background . ,iright)  (right-edge . -9) (top-edge . 0)   (bottom-edge . 0)  (class . right-border))
        ((background . ,ileft)    (left-edge . -6) (top-edge . 0)   (bottom-edge . 0)  (class . left-border))
        ((background . ,ibottom) (right-edge . 0)  (left-edge . 0) (bottom-edge . -10) (class . bottom-border))
        ((background . ,ibottomleft)     (left-edge . -6) (bottom-edge . -10) (class . bottom-left-corner))
        ((background . ,ibottomright)     (right-edge . -9) (bottom-edge . -10) (class . bottom-right-corner))
        ((background . ,iclose)  (right-edge . 5)  (top-edge . -30)                    (class . close-button))
        ((background . ,imax)    (right-edge . 30)  (top-edge . -30)                    (class . maximize-button))
        ((background . ,imin)    (right-edge . 55)   (top-edge . -30)                    (class . iconify-button))
        ((background . ,imenu)         (left-edge . 10)   (top-edge . -25)                    (class . menu-button))
      )
    )																																													

(shaped-frame
     `(
        ((background . ,itopright)  (right-edge . -9) (top-edge . -30) (class . title))
        ((background . ,itopcenter-right)  (right-edge . 90) (width . 80) (top-edge . -30) (class . title))
        ((background . ,itopcenter-center)  (right-edge . 0) (width . 90)(top-edge . -30) (class . title))
        ((background . ,itopcenter-left)  (left-edge . 0) (width . 50)(top-edge . -30) (class . title))
        ((background . ,itopleft) (left-edge . -6) (height . 30) (top-edge . -30) (class . title))
        ((background . ,ititle)  (right-edge . 170) (left-edge . 50) (top-edge . -30) 
         (foreground . ("red" "blue"))  (text . ,window-name) (x-justify . center) (y-justify . bottom) (class . title))
        ((background . ,ibottom) (right-edge . 0)  (left-edge . 0) (top-edge . 0) (class . bottom-border))
        ((background . ,ibottomleft)     (left-edge . -6) (top-edge . 0) (class . bottom-left-corner))
        ((background . ,ibottomright)     (right-edge . -9) (top-edge . 0) (class . bottom-right-corner))
        ((background . ,iclose)  (right-edge . 5)  (top-edge . -30)                    (class . close-button))
        ((background . ,imax)    (right-edge . 30)  (top-edge . -30)                    (class . maximize-button))
        ((background . ,imin)    (right-edge . 55)   (top-edge . -30)                    (class . iconify-button))
        ((background . ,imenu)         (left-edge . 10)   (top-edge . -25)                    (class . menu-button))
      )
    )
  )

  (add-frame-style 'xanth-sawfish
    (lambda (w type) 
      (case type 
        ((default) default-frame)
        ((unframed) default-frame)
        ((transient) default-frame)
        ((shaped) shaped-frame)
        ((shaped-transient) default-frame)
      )
    )
  )
)

